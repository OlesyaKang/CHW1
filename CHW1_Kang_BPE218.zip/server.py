import sys

from flask import Flask, jsonify, request
from data import db_session
from data.models.users import User

app = Flask(__name__)

players_online = 0

draw = False
running = True
current_turn = 1

board = [[0, 0, 0],
         [0, 0, 0],
         [0, 0, 0]]


@app.route("/add_user", methods=['POST'])
def add_user():
    global players_online

    if players_online + 1 > 2:
        return jsonify({"answer": "full"}), 403
    else:
        players_online += 1
    name = request.json.get("player_name")
    db_sess = db_session.create_session()
    if name not in [user.name for user in db_sess.query(User).all()]:
        user = User()
        user.name = name
        db_sess.add(user)
        db_sess.commit()
        return jsonify({"answer": "new", "turn": players_online - 1}), 200
    return jsonify({"answer": "old", "turn": players_online - 1}), 200


@app.route("/do_move", methods=["POST"])
def do_move():
    global current_turn
    current_turn = request.json.get("current_turn")
    return jsonify({"new_turn": abs(current_turn - 1)}), 200


@app.route("/get_turn_run_draw", methods=["POST"])
def get_current_turn():
    global current_turn
    global running
    global draw
    if draw:
        running = False
    return jsonify({"current_turn": abs(current_turn - 1),
                    "running": running, "draw": draw}), 200


@app.route("/get_board", methods=["POST"])
def get_board():
    global board
    board = request.json.get("board")
    return jsonify({"message": "ok"}), 200


@app.route("/set_board", methods=["POST"])
def set_board():
    global board
    return jsonify({"board": board}), 200


@app.route("/is_win", methods=["POST"])
def is_win():
    check_win = False
    check_draw = False
    client_turn = request.json.get("my_turn")
    win = [[(0, 0), (0, 1), (0, 2)],
           [(1, 0), (1, 1), (1, 2)],
           [(2, 0), (2, 1), (2, 2)],
           [(0, 0), (1, 0), (2, 0)],
           [(0, 1), (1, 1), (2, 1)],
           [(0, 2), (1, 2), (2, 2)],
           [(0, 0), (1, 1), (2, 2)],
           [(0, 2), (1, 1), (2, 0)]]
    for pos in win:
        if all([board[yx[0]][yx[1]] == client_turn for yx in pos]):
            check_win = True
            break
    if any([any([tile == 0 for tile in row]) for row in board]):
        check_draw = False
    else:
        check_draw = True
    global draw
    draw = check_draw
    if check_win:
        global running
        running = False
    return jsonify({"is_win": check_win, "running": running}), 200


if __name__ == '__main__':
    db_session.global_init("db/tic_tac_toe.db")
    db_sess = db_session.create_session()

    app.run(port=8080, host='127.0.0.1')