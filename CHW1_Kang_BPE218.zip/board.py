import pygame
import requests
import sys


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        try:
            url = 'http://127.0.0.1:8080/set_board'
            response = requests.post(url)
            self.board = response.json()["board"]
        except Exception as e:
            print(f'Error on connecting to remote application.\n{e}')
            sys.exit()
        self.left = 0
        self.top = 0
        self.cell_size = 100

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        try:
            url = 'http://127.0.0.1:8080/set_board'
            response = requests.post(url)
            self.board = response.json()["board"]
        except Exception as e:
            print(f'Error on connecting to remote application.\n{e}')
            sys.exit()
        for y in range(self.height):
            for x in range(self.width):
                if self.board[y][x] == 0:
                    pygame.draw.rect(screen, pygame.Color("White"),
                                 (self.left + self.cell_size * x, self.top + self.cell_size * y,
                                  self.cell_size, self.cell_size))
                elif self.board[y][x] == 1:
                    pygame.draw.line(screen, pygame.Color("Red"),
                                     (self.left + self.cell_size * x, self.top + self.cell_size * y),
                                     (self.left + self.cell_size * x + self.cell_size,
                                      self.top + self.cell_size * y + self.cell_size), 2)
                    pygame.draw.line(screen, pygame.Color("Red"),
                                     (self.left + self.cell_size * x + self.cell_size,
                                      self.top + self.cell_size * y),
                                     (self.left + self.cell_size * x,
                                      self.top + self.cell_size * y + self.cell_size), 2)
                elif self.board[y][x] == 2:
                    pygame.draw.ellipse(screen, pygame.Color("Blue"),
                                     (self.left + self.cell_size * x + 1, self.top + self.cell_size * y + 1,
                                      self.cell_size - 2, self.cell_size - 2), 2)
                pygame.draw.rect(screen, pygame.Color("Black"),
                                 (self.left + self.cell_size * x, self.top + self.cell_size * y,
                                  self.cell_size, self.cell_size), 2)

    def get_click(self, mouse_pos, turn):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell, turn)

    def get_cell(self, pos):
        x = (pos[0] - self.left) // self.cell_size
        y = (pos[1] - self.top) // self.cell_size
        if (x > self.width - 1 or x < 0) or (y > self.height - 1 or y < 0):
            return None
        return tuple([x, y])

    def on_click(self, cell, turn):
        if cell is None:
            return
        if cell[0] not in range(3) or cell[1] not in range(3):
            return
        if self.board[cell[1]][cell[0]] == 0:
            self.board[cell[1]][cell[0]] = turn + 1
            try:
                url = 'http://127.0.0.1:8080/get_board'
                data = {'board': self.board}
                response = requests.post(url, json=data)
            except Exception as e:
                print(f'Error on connecting to remote application.\n{e}')
                sys.exit()

    def is_free(self, pos):
        cell = self.get_cell(pos)
        return self.board[cell[1]][cell[0]] == 0
