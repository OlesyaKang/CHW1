import sys
import requests
import pygame
from board import Board

def game():
    print("Enter your name")
    name = input()
    try:
        url = 'http://127.0.0.1:8080/add_user'
        data = {'player_name': name}
        response = requests.post(url, json=data)
        answer = response.json()["answer"]
        if answer == "new":
            print("Hi, glad to see a new person! Wish you luck!")
        elif answer == "old":
            print("So you've already played this game? Good luck this time too!")
        elif answer == "full":
            print("Sorry, but there are two players in the game already. Try to connect later.")
            sys.exit()
        turn = response.json()["turn"]
    except Exception as e:
        print(f'Error on connecting to remote application.\n{e}')
        sys.exit()
    if turn == 0:
        print("Waiting for a second player")

    width, height = 300, 300
    pygame.init()
    screen = pygame.display.set_mode([width, height])
    board = Board(3, 3)
    board.render(screen)
    running = True
    while running:
        try:
            url = 'http://127.0.0.1:8080/get_turn_run_draw'
            response = requests.post(url)
            current_turn = response.json()["current_turn"]
            running = response.json()["running"]
            is_draw = response.json()["draw"]
        except Exception as e:
            print(f'Error on connecting to remote application.\n{e}')
            sys.exit()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN and current_turn == turn:
                if board.is_free(event.pos):
                    try:
                        url = 'http://127.0.0.1:8080/do_move'
                        data = {'current_turn': current_turn}
                        response = requests.post(url, json=data)
                        current_turn = response.json()["new_turn"]
                    except Exception as e:
                        print(f'Error on connecting to remote application.\n{e}')
                        sys.exit()
                    board.get_click(event.pos, turn)
                    try:
                        url = 'http://127.0.0.1:8080/is_win'
                        data = {'my_turn': turn + 1}
                        response = requests.post(url, json=data)
                        is_win = response.json()["is_win"]
                        running = response.json()["running"]
                    except Exception as e:
                        print(f'Error on connecting to remote application.\n{e}')
                        sys.exit()
        screen.fill((255, 255, 255))
        board.render(screen)
        pygame.display.flip()
    if is_win:
        print(f"Вы победили, {name}!")
    elif is_draw:
        print("Вы сыграли вничью!")
    else:
        print(f"Вы проиграли, {name}...")
    pygame.quit()

game()